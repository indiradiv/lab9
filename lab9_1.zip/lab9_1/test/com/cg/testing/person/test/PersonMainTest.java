package com.cg.testing.person.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.testing.model.PersonClass;

public class PersonMainTest {

	PersonMainTest object;
	@Before
	public void setUp() throws Exception {
		object=new PersonMainTest();
	}

	@After
	public void tearDown() throws Exception {
		object=null;
	}

	@Test
	public void testDisplay() {
		PersonClass class1 = new PersonClass("indira", "divvela", 'F');
		String fName =class1.getFirstName();
		assertEquals(fName,"indira");
		String lName=class1.getLastName();
		assertEquals(lName,"divvela");
		char gender=class1.getGender();
		assertEquals(gender,'F');
		
		
	}

}
