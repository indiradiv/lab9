package com.cg.testing.person;

import java.util.Scanner;

import com.cg.testing.model.PersonClass;

public class PersonMain {

	public static void main(String[] args) {

		System.out.println("Enter first name");
		Scanner scanner = new Scanner(System.in);
		String fName = scanner.nextLine();
		System.out.println("Enter last name");
		String lName = scanner.nextLine();
		System.out.println("enter gender");
		char gender = scanner.nextLine().charAt(0);
		PersonClass class1 = new PersonClass(fName, lName, gender);
		display(class1);

		scanner.close();
	}

	public static void display(PersonClass class1) {

		System.out.println("Person Details:");
		System.out.println("______________________________");
		System.out.println("First Name: " + class1.getFirstName());
		System.out.println("Last Name: " + class1.getLastName());
		System.out.println("Gender: " + class1.getGender());
	}

}
