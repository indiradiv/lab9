package com.cg.testing.service;

import com.cg.testing.exception.ExceptionCheck;

public interface EmployeeService {

	String validateFields(double salary, String designation);

	void validSal(Double salary) throws ExceptionCheck;

}
