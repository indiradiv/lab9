package com.cg.testing.presentation;

import java.util.Scanner;

import com.cg.testing.bean.Employee;
import com.cg.testing.exception.ExceptionCheck;
import com.cg.testing.service.EmployeeService;
import com.cg.testing.service.EmployeeServiceImp;

public class MainClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Employee employee = new Employee();
		EmployeeService service = null;
		System.out.println("Welcome to Employee Insurance Scheme");
		System.out.println("Enter the employee id");
		int id = sc.nextInt();
		System.out.println("enter the employee name");
		sc.nextLine();
		String name = sc.nextLine();
		System.out.println("Enter the Desig");
		String designation = sc.nextLine();
		System.out.println("enter the employee salary");

		Double salary = sc.nextDouble();
		try {
			if (salary < 3000) {
				service = new EmployeeServiceImp();
				 service.validSal(salary);
				
			}

			else {
				employee.setName(name);
				employee.setId(id);
				employee.setSalary(salary);
				employee.setDesignation(designation);

				EmployeeService service1 = new EmployeeServiceImp();
				String insuranceScheme = service1.validateFields(salary, designation);
				employee.setInsurancescheme(insuranceScheme);
				System.out.println(" Id: " + employee.getId() + "\n Name: " + employee.getName() + "\n Designation: "
						+ employee.getDesignation() + "\n Salary: " + employee.getSalary() + "\n Insurance Scheme: "
						+ employee.getInsurancescheme());
				sc.close();
			}

		} catch (ExceptionCheck e) {
			System.out.println(e.getMessage());

		}

	}

}
